import re
import ctypes
import sys
import winsound

def search(arg):

    if arg != 'x':        
        ready = input("\nType 'x' to use copied HTML code: ")
        if ready != 'x':
            search(arg)

    CF_TEXT = 1

    kernel32 = ctypes.windll.kernel32
    user32 = ctypes.windll.user32

    user32.OpenClipboard(0)
    if user32.IsClipboardFormatAvailable(CF_TEXT):
        data = user32.GetClipboardData(CF_TEXT)
        data_locked = kernel32.GlobalLock(data)
        text = ctypes.c_char_p(data_locked)
        #print(text.value)
        kernel32.GlobalUnlock(data_locked)
        html_code = str(text.value)
    else:
        print('no text in clipboard')
        if arg == 'x':
            return
        search(arg)
    user32.CloseClipboard()
        
    search_correct = re.search('( correct-option)', html_code)
    occurances = html_code.count(" correct-option")

    if search_correct != None:
        print("CORRECT Found:\n")
        s = str(search_correct)
        s_location = s[s.find("(")+1:s.find(")")]
        s_location_start = int(s_location.split(', ', 1)[0])
        s_location_end = int(s_location.split(', ', 1)[1])
        #print("Location: " + s_location)
        title = html_code[html_code.find('<title>'):html_code.find('</title>')].replace('<title>', "")
        question_unclipped = html_code[html_code.find('<meta name="description" content="'):800]
        question = question_unclipped[question_unclipped.find('<meta name="description" content="'):question_unclipped.find('">')].replace('<meta name="description" content="', "")
        f = open("answers.txt", "a+")
        print("TITLE: " + title)
        f.write("TITLE: " + title + "\n")
        print("QUESTION: " + question)
        f.write("QUESTION: " + question + "\n")
        for x in range(0, occurances):
            correct_splice = html_code[s_location_start:s_location_end + 3200]
            print("Splice: " + correct_splice)
            letter = correct_splice[correct_splice.find("fa-check\">"):correct_splice.find("</span>")].replace("fa-check\">", "")
            text = correct_splice[correct_splice.find("-->"):len(correct_splice)+1].replace("-->", "")
            text = text[0:text.find("<!--")].replace("<!--", "")
            if text.startswith("<span") and re.search('(MathJax)', text) != None:
                orig_text = text
                occurancesMathItalic = text.count('MathJax_Math-italic;">')
                text_list = []
                for y in range(0, occurancesMathItalic):
                    text = text.replace('MathJax_Math-italic;">', "", y)
                    cur_text = text[text.find('MathJax_Math-italic;">'):len(text)+1].replace('MathJax_Math-italic;">', "")
                    cur_text = cur_text[0:cur_text.find('</span>')]
                    text_list.append(cur_text)
                text = ''.join(text_list)
                occurancesMath = orig_text.count('MathJax_Main;">')
                text_list = []
                for y in range(0, occurancesMath):
                    orig_text = orig_text.replace('MathJax_Main;">', "", y)
                    cur_text = orig_text[orig_text.find('MathJax_Main;">'):len(orig_text)+1].replace('MathJax_Main;">', "")
                    cur_text = cur_text[0:cur_text.find('</span>')]
                    text_list.append(cur_text)
                text += ''.join(text_list)
            elif re.search('(MathJax)', text) != None:
                old_text = text[0:text.find('<span')]

                orig_text = text
                occurancesMathItalic = text.count('MathJax_Math-italic;">')
                text_list = []
                for y in range(0, occurancesMathItalic):
                    text = text.replace('MathJax_Math-italic;">', "", y)
                    cur_text = text[text.find('MathJax_Math-italic;">'):len(text)+1].replace('MathJax_Math-italic;">', "")
                    cur_text = cur_text[0:cur_text.find('</span>')]
                    text_list.append(cur_text)
                text = ''.join(text_list)
                occurancesMath = orig_text.count('MathJax_Main;">')
                text_list = []
                for y in range(0, occurancesMath):
                    orig_text = orig_text.replace('MathJax_Main;">', "", y)
                    cur_text = orig_text[orig_text.find('MathJax_Main;">'):len(orig_text)+1].replace('MathJax_Main;">', "")
                    cur_text = cur_text[0:cur_text.find('</span>')]
                    text_list.append(cur_text)
                text += ''.join(text_list)
                
                text = old_text + text
            text = text.replace('<span style="display: inline-block; overflow: hidden; height: 1px; width: 0.064em;">', "")
            text = text.replace('<span style="display: inline-block; overflow: hidden; height: 1px; width: 0.003em;">', "")
            print("ANSWER: " + letter + ": " + text)
            f.write("ANSWER: " + letter + ": " + text + "\n")
            html_code = html_code.replace(html_code[s_location_start:s_location_end + 400], "")
            search_correct = re.search('( correct-option)', html_code)
            if search_correct != None:
                s = str(search_correct)
                s_location = s[s.find("(")+1:s.find(")")]
                s_location_start = int(s_location.split(', ', 1)[0])
                s_location_end = int(s_location.split(', ', 1)[1])
                
        f.write("\n")
        f.close()
        
    else:    
        print("No correct answer has been found. Please try again.")
        winsound.Beep(2500, 250)

    if arg == 'x':
        return
    search(arg)

if __name__ == "__main__":
    arg = ''
    if len(sys.argv) == 2:
        arg = str(sys.argv[1])
    search(arg)
