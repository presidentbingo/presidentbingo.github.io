def main():

    file_name = input("Welcome to the ToWebsite Script for Albert.io! (@michaelvuolo_ on twitter)\n\tImport File Name: ")

    try:
        f = open(file_name + ".txt","r", encoding="utf8")
        if f.mode == 'r':
            contents = f.read()
        f.close()
    except:
        print("ERROR READING FILE! (make sure not to include `.txt`)\n")
        main()

    converted_contents = "";
    lines = contents.splitlines()

    for line in lines:
        if len(line) == 0:
            converted_contents += "<br>" + "\n";
        elif len(line) > 0 and line.startswith("ANSWER"):
            converted_contents += "<li>" + "😈 " + line + "</li>" + "\n";
        elif len(line) > 0:
            converted_contents += "<li>" + line + "</li>" + "\n";

    try:
        f = open(file_name.lower().replace(".txt", "") + "_toWEBSITE" + ".txt","w+", encoding="utf8")
        f.write(converted_contents)
        f.close()
        print("\n~File Converted! [" + file_name.lower().replace(".txt", "") + "_toWEBSITE" + ".txt" + "]\n")
    except:
        print("ERROR WRITING FILE!\n")

    main()

main()
